package com.rockradionet.player

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Metadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.metadata.icy.IcyInfo
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Фоновое воспроизведение радио. Работает при закрытом приложении и заблокированном экране,
 * показывает уведомление с кнопками, принимает кнопки Bluetooth-гарнитуры (через MediaSession),
 * читает название трека из потока (ICY) и обновляет виджет.
 */
@OptIn(UnstableApi::class)
class RadioService : MediaSessionService() {

    companion object {
        const val A_TOGGLE = "com.rockradionet.player.TOGGLE"
        const val A_PLAY = "com.rockradionet.player.PLAY"
        const val A_PAUSE = "com.rockradionet.player.PAUSE"
        const val A_NEXT = "com.rockradionet.player.NEXT"
        const val A_PREV = "com.rockradionet.player.PREV"
        const val A_RECONNECT = "com.rockradionet.player.RECONNECT"
        const val A_SHUFFLE = "com.rockradionet.player.SHUFFLE"
        const val EXTRA_INDEX = "index"

        @Volatile
        var instance: RadioService? = null
            private set

        /** Последнее состояние в JSON для веб-интерфейса. Пусто, если сервис не запущен. */
        @Volatile
        var stateJson: String = ""

        /** Подписчики на изменения (вызываются в главном потоке). */
        val listeners = CopyOnWriteArraySet<() -> Unit>()

        /** Громкость звучащей музыки (RMS, 0…1) — для стрелки тахометра на странице, и когда её измерили. */
        @Volatile
        var level = 0f
        @Volatile
        var levelAt = 0L
    }

    /** Копия звука после декодирования: считаем громкость музыки. Звук не меняется, разрешения не нужны. */
    private val levelSink = object : TeeAudioProcessor.AudioBufferSink {
        @Volatile
        private var encoding = C.ENCODING_INVALID

        override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
            this.encoding = encoding
        }

        override fun handleBuffer(buffer: ByteBuffer) {
            val b = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            var sum = 0.0
            var n = 0
            when (encoding) {
                C.ENCODING_PCM_16BIT -> {
                    while (b.remaining() >= 8) {
                        val v = b.getShort(b.position()) / 32768.0
                        sum += v * v; n++
                        b.position(b.position() + 8)
                    }
                }
                C.ENCODING_PCM_FLOAT -> {
                    while (b.remaining() >= 16) {
                        val v = b.getFloat(b.position()).toDouble()
                        sum += v * v; n++
                        b.position(b.position() + 16)
                    }
                }
                else -> return
            }
            if (n == 0) return
            level = Math.sqrt(sum / n).toFloat().coerceIn(0f, 1f)
            levelAt = SystemClock.elapsedRealtime()
        }
    }

    private lateinit var player: ExoPlayer
    private var session: MediaSession? = null
    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newFixedThreadPool(2)

    private var stations: List<Station> = emptyList()
    private var index = -1

    private var raw = ""
    private var artist = ""
    private var title = ""
    private var coverUrl = ""
    private var cover: Bitmap? = null
    @Volatile private var coverTries = 0
    private var logo: Bitmap? = null
    private var logoFor = ""
    private var error = ""
    private var retries = 0
    private var startedAt = 0L

    private val retryRunnable = Runnable {
        if (index >= 0) {
            player.prepare()
            player.play()
        }
    }
    private val refreshRunnable = Runnable { notifyChanged() }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Net.assets = applicationContext.assets
        stations = Store.stations(this)
        val savedUrl = Store.currentUrl(this)
        index = stations.indexOfFirst { it.url == savedUrl }

        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("RockRadioNet/1.0 (Android)")
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(arrayOf<AudioProcessor>(TeeAudioProcessor(levelSink)))
                .build()
        }

        player = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true) // пауза, если отключили наушники
            .setWakeMode(C.WAKE_MODE_NETWORK)  // не засыпать при выключенном экране
            .build()
        player.volume = Store.volume(this)
        player.addListener(listener)

        // У радио один «трек» — поток. Обёртка добавляет кнопки «назад/вперёд» (переключение станций)
        // в уведомление, на экран блокировки и для гарнитуры.
        val controls = object : ForwardingPlayer(player) {
            override fun getAvailableCommands(): Player.Commands =
                super.getAvailableCommands().buildUpon()
                    .add(Player.COMMAND_SEEK_TO_NEXT)
                    .add(Player.COMMAND_SEEK_TO_NEXT_MEDIA_ITEM)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS)
                    .add(Player.COMMAND_SEEK_TO_PREVIOUS_MEDIA_ITEM)
                    .add(Player.COMMAND_PLAY_PAUSE)
                    .build()

            override fun isCommandAvailable(command: Int): Boolean =
                availableCommands.contains(command)

            override fun seekToNext() = step(1)
            override fun seekToNextMediaItem() = step(1)
            override fun seekToPrevious() = step(-1)
            override fun seekToPreviousMediaItem() = step(-1)
            override fun play() = resume()
        }

        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, controls).setSessionActivity(open).build()
        notifyChanged()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.action?.let { handle(it, intent.getIntExtra(EXTRA_INDEX, -1)) }
        return super.onStartCommand(intent, flags, startId)
    }

    /** Команды от приложения и виджета. Вызывать в главном потоке. */
    fun handle(action: String, idx: Int = -1) {
        when (action) {
            A_TOGGLE -> toggle()
            A_PLAY -> if (idx >= 0) playIndex(idx) else resume()
            A_PAUSE -> player.pause()
            A_NEXT -> step(1)
            A_PREV -> step(-1)
            A_RECONNECT -> playIndex(maxOf(index, 0), keepTrack = true)
            A_SHUFFLE -> shuffle()
        }
    }

    private fun isActive(): Boolean =
        player.playWhenReady &&
            player.playbackState != Player.STATE_IDLE &&
            player.playbackState != Player.STATE_ENDED

    private fun toggle() {
        if (isActive()) player.pause() else resume()
    }

    /** Возобновление: у живого эфира заново подключаемся к потоку, чтобы не играть старый буфер. */
    private fun resume() {
        if (stations.isEmpty()) return
        playIndex(if (index < 0) 0 else index, keepTrack = true)
    }

    private fun step(d: Int) {
        if (stations.isEmpty()) return
        playIndex(if (index < 0) 0 else index + d)
    }

    private fun shuffle() {
        val n = stations.size
        if (n < 2) {
            resume(); return
        }
        var i: Int
        do {
            i = (0 until n).random()
        } while (i == index)
        playIndex(i)
    }

    fun playIndex(i: Int, keepTrack: Boolean = false) {
        val n = stations.size
        if (n == 0) return
        val ni = ((i % n) + n) % n
        val changed = ni != index
        index = ni
        val st = stations[ni]
        Store.saveCurrentUrl(this, st.url)
        main.removeCallbacks(retryRunnable)
        retries = 0
        error = ""
        if (changed || !keepTrack) clearTrack()
        startedAt = System.currentTimeMillis()
        player.setMediaItem(mediaItem(st))
        player.prepare()
        player.play()
        loadLogo(st)
        notifyChanged()
        main.removeCallbacks(refreshRunnable)
        main.postDelayed(refreshRunnable, 13_000) // чтобы страница поняла, что названия трека нет
    }

    /** Повторно разослать состояние (виджету и странице). */
    fun refresh() = notifyChanged()

    fun setVolume(v: Float) {
        player.volume = v.coerceIn(0f, 1f)
    }

    /** Список станций изменили в приложении: сохраняем текущую станцию по ссылке. */
    fun reloadStations() {
        val curUrl = if (index in stations.indices) stations[index].url else Store.currentUrl(this)
        stations = Store.stations(this)
        val ni = stations.indexOfFirst { it.url == curUrl }
        if (ni < 0 && index >= 0) {
            index = -1
            player.stop()
            player.clearMediaItems()
            clearTrack()
        } else {
            index = ni
            if (ni >= 0) loadLogo(stations[ni])
        }
        notifyChanged()
    }

    private fun mediaItem(st: Station): MediaItem {
        val meta = MediaMetadata.Builder()
            .setTitle(st.name)
            .setArtist(st.genre.ifBlank { "Интернет-радио" })
        when {
            st.logo.startsWith("http") -> meta.setArtworkUri(Uri.parse(st.logo))
            st.logo.startsWith("data:image") -> try {
                meta.setArtworkData(
                    Base64.decode(st.logo.substringAfter(','), Base64.DEFAULT),
                    MediaMetadata.PICTURE_TYPE_FRONT_COVER
                )
            } catch (e: Exception) {
                // битая картинка — уведомление покажет значок по умолчанию
            }
        }
        return MediaItem.Builder()
            .setUri(st.url)
            .setMediaId(st.url)
            .setMediaMetadata(meta.build())
            .build()
    }

    private fun clearTrack() {
        raw = ""; artist = ""; title = ""; coverUrl = ""; cover = null
    }

    private fun loadLogo(st: Station) {
        if (st.logo == logoFor && logo != null) return
        logoFor = st.logo
        logo = null
        if (st.logo.isBlank()) return
        val key = st.logo
        io.execute {
            val b = Net.bitmap(key, 300)
            main.post {
                if (logoFor == key) {
                    logo = b; notifyChanged()
                }
            }
        }
    }

    private fun onStreamTitle(t: String?, streamUrl: String? = null) {
        val s = t?.trim().orEmpty()
        // Картинка, которую передаёт сама станция (поле StreamUrl в потоке)
        val streamImg = streamUrl?.trim().orEmpty().takeIf { Net.looksLikeImage(it) }.orEmpty()
        if (s == raw) {
            if (streamImg.isNotEmpty() && streamImg != coverUrl) loadCover(streamImg, s, searchIfFails = false)
            return
        }
        // Режим «Случайная»: трек сменился — включаем случайную станцию
        // (не сразу после переключения: первое название новой станции — не смена трека)
        if (raw.isNotEmpty() && s.isNotEmpty() && Store.shuffleMode(this) &&
            System.currentTimeMillis() - startedAt > 20_000L
        ) {
            main.post { shuffle() }
            return
        }
        raw = s
        val sep = Regex("\\s[-–—]\\s").find(s)
        if (s.isEmpty()) {
            artist = ""; title = ""
        } else if (sep != null && sep.range.first > 0) {
            artist = s.substring(0, sep.range.first).trim()
            title = s.substring(sep.range.last + 1).trim()
        } else {
            artist = ""; title = s
        }
        // пока ищем новую обложку, оставляем прежнюю (артист/альбом), а не логотип станции
        if (title.isEmpty()) { coverUrl = ""; cover = null }
        notifyChanged()
        coverTries = 0
        when {
            streamImg.isNotEmpty() -> loadCover(streamImg, raw, searchIfFails = true)
            title.isNotEmpty() -> searchCover()
        }
    }

    /** Найти обложку альбома или фото исполнителя (по настройке). */
    private fun searchCover() {
        if (title.isEmpty()) return
        val a = artist
        val tt = title
        val key = raw
        val mode = Store.coverMode(this)
        io.execute {
            val url = Net.findCover(a, tt, mode)
            if (url != null) main.post { if (raw == key) loadCover(url, key) }
            else if (coverTries++ < 2) main.postDelayed({ if (raw == key) searchCover() }, 15000)
        }
    }

    private fun loadCover(url: String, key: String, searchIfFails: Boolean = false) {
        io.execute {
            val bmp = Net.bitmap(url, 400)
            main.post {
                if (raw != key) return@post
                if (bmp != null) {
                    coverUrl = url; cover = bmp; notifyChanged()
                } else if (searchIfFails) {
                    searchCover() // картинка из потока не открылась — ищем сами
                }
            }
        }
    }

    /** Сменили «альбом / исполнитель» в настройках — ищем картинку заново (кроме картинки из потока). */
    fun refetchCover() {
        if (title.isEmpty()) return
        val searched = coverUrl.isEmpty() || coverUrl.contains("mzstatic") || coverUrl.contains("dzcdn")
        if (!searched) return
        coverUrl = ""; cover = null; notifyChanged()
        searchCover()
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                retries = 0; error = ""
            }
            notifyChanged()
        }

        override fun onPlaybackStateChanged(playbackState: Int) = notifyChanged()

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = notifyChanged()

        override fun onPlayerError(e: PlaybackException) {
            if (retries < 3 && index >= 0) {
                retries++
                error = "Переподключение ($retries/3)…"
                main.postDelayed(retryRunnable, 1500L * retries)
            } else {
                error = "Поток недоступен"
            }
            notifyChanged()
        }

        override fun onMetadata(metadata: Metadata) {
            for (i in 0 until metadata.length()) {
                val entry = metadata.get(i)
                if (entry is IcyInfo) onStreamTitle(entry.title, entry.url)
            }
        }
    }

    private fun notifyChanged() {
        val st = stations.getOrNull(index)
        stateJson = JSONObject().apply {
            put("index", index)
            put("playing", isActive())
            put("buffering", player.playbackState == Player.STATE_BUFFERING)
            put("raw", raw)
            put("artist", artist)
            put("title", title)
            put("cover", coverUrl)
            put("error", error)
            put("since", if (startedAt == 0L) 0L else (System.currentTimeMillis() - startedAt) / 1000L)
        }.toString()
        Widget.update(
            this,
            Widget.State(
                hasStations = stations.isNotEmpty(),
                hasCurrent = st != null,
                name = st?.name ?: "",
                genre = st?.genre ?: "",
                artist = artist,
                title = title,
                playing = isActive(),
                error = error,
                image = cover ?: logo ?: st?.let { Net.letterBitmap(it.name) }
            )
        )
        for (l in listeners) l()
    }

    /** Полная остановка по просьбе пользователя: звук выключается, уведомление убирается, служба завершается. */
    fun shutdown() {
        main.removeCallbacksAndMessages(null)
        try {
            player.stop()
            player.clearMediaItems()
        } catch (e: Exception) {
        }
        startedAt = 0L
        session?.release()
        session = null
        try {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
        }
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Приложение смахнули из списка недавних: если радио не играет — завершаемся.
        if (!isActive()) stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        io.shutdownNow()
        session?.release()
        session = null
        player.removeListener(listener)
        player.release()
        instance = null
        stateJson = ""
        Widget.update(this)
        for (l in listeners) l()
        super.onDestroy()
    }
}
