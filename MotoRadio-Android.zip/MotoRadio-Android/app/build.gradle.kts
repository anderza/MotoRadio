plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rockradionet.player"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.motoradio.player"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Подпись отладочным ключом, чтобы release-APK можно было сразу установить.
            // Для публикации в Google Play замените на свой ключ.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    val media3 = "1.4.1"
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-session:$media3")
}

// Обложки станций: при сборке в GitHub Actions скачиваются и встраиваются в приложение
// (tools/bundle_covers.py). Если что-то не получилось, сборка идёт дальше, а обложки грузятся с сайтов.
val bundleCovers by tasks.registering(Exec::class) {
    workingDir = rootDir
    commandLine(
        "bash", "-c",
        "if grep -q '\"l\":\"covers/' app/src/main/assets/www/index.html; then echo 'Обложки уже встроены'; exit 0; fi; " +
            "python3 -c 'import PIL' 2>/dev/null || python3 -m pip install --quiet --user --break-system-packages pillow || python3 -m pip install --quiet --user pillow || true; " +
            "python3 tools/bundle_covers.py app/src/main/assets/www/index.html || true"
    )
    isIgnoreExitValue = true
    onlyIf { System.getenv("CI") == "true" && rootDir.resolve("tools/bundle_covers.py").exists() }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(bundleCovers) }
